import type { Locale } from "./types";

export function signupGrantLabel(locale: Locale, revoked = false): string {
  if (revoked) {
    const labels: Record<Locale, string> = {
      "zh-TW": "註冊贈送撤回",
      en: "Welcome gift reversal",
      "ja-JP": "登録特典の取り消し",
      "th-TH": "เรียกคืนของขวัญสมัครสมาชิก",
    };
    return labels[locale];
  }
  const labels: Record<Locale, string> = {
    "zh-TW": "新用戶註冊贈送",
    en: "New account welcome gift",
    "ja-JP": "新規登録特典",
    "th-TH": "ของขวัญสำหรับบัญชีใหม่",
  };
  return labels[locale];
}
