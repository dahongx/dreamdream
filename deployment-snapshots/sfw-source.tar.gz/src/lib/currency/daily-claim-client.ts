export interface DailyClaimResponse {
  claimed: boolean;
  amount: number;
  newBalance: number;
  message: string;
}
export function claimDay(now = new Date()): string {
  return new Date(now.getTime() + 8 * 3600000).toISOString().slice(0, 10);
}
/** Memory-only, account/date scoped. Failed requests never suppress a retry. */
export function createDailyClaimClient(
  userId: string,
  send: (id: string) => Promise<DailyClaimResponse>,
) {
  let completedDay = "";
  let pending = false;
  return async (now = new Date()): Promise<DailyClaimResponse | null> => {
    const day = claimDay(now);
    if (pending || completedDay === day) return null;
    pending = true;
    try {
      const result = await send(userId);
      completedDay = day;
      return result;
    } finally {
      pending = false;
    }
  };
}
