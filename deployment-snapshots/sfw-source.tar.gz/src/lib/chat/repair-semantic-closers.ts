/** Render-only recovery for a model closing a speech tag as narration (or vice versa). */
export function repairSemanticClosers(source: string): string {
  const stack: string[] = [];
  const kind = (tag: string) => /^(message|mes)$/i.test(tag) ? "speech" : "narration";
  // Code examples and authored document blocks are opaque, not protocol tokens.
  const tokens = /<!--[\s\S]*?(?:-->|$)|```[\s\S]*?(?:```|$)|`[^`\n]*`|<(script|style|pre|code|artifact)\b[^>]*>[\s\S]*?(?:<\/\1\s*>|$)|<\/?(message|mes|narration|nar)\s*>/gi;
  return source.replace(tokens, (token: string, _opaqueTag?: string, name?: string) => {
    if (!name) return token;
    if (!token.startsWith("</")) {
      stack.push(name);
      return token;
    }
    const top = stack.at(-1);
    if (!top) return token;
    if (kind(top) === kind(name)) {
      stack.pop();
      return top.toLowerCase() === name.toLowerCase() ? token : `</${top}>`;
    }
    const ancestor = stack.findLastIndex((tag) => kind(tag) === kind(name));
    if (ancestor !== -1) {
      // An ancestor close is ambiguous; leave the authored token untouched.
      stack.length = ancestor;
      return token;
    }
    stack.pop();
    return `</${top}>`;
  });
}
