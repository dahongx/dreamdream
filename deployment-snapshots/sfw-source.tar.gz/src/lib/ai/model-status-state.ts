export type ModelStabilityStatus =
  | "smooth"
  | "congested"
  | "interrupted"
  | "unknown";

export interface ModelStatusInputs {
  sampleCount: number;
  successCount: number;
  averageTtftMs: number | null;
}

/** Persistent snapshot from real traffic, independent of legacy probes. */
export interface RealModelStatusState extends ModelStatusInputs {
  observedAt: string;
  stabilityStatus: ModelStabilityStatus;
  channelFailureAt: string | null;
  lastSuccessAt: string | null;
  channelInterrupted: boolean;
}

export interface ModelStatusAttempt {
  outcome: "success" | "failure";
  channelFailure?: boolean;
  observedAt: Date;
}

export function classifyModelStability({
  sampleCount,
  successCount,
  averageTtftMs,
}: ModelStatusInputs): ModelStabilityStatus {
  if (sampleCount < 1) return "unknown";
  const rate = (successCount / sampleCount) * 100;
  if (rate < 50) return "interrupted";
  if (rate < 90 || (averageTtftMs !== null && averageTtftMs >= 15_000))
    return "congested";
  return "smooth";
}

export function mapProbeHealthStatus(status: string): ModelStabilityStatus {
  if (status === "healthy") return "smooth";
  if (status === "degraded") return "congested";
  if (status === "unhealthy") return "interrupted";
  return "unknown";
}

export function buildRealModelStatusState(
  previous: RealModelStatusState | null,
  attempt: ModelStatusAttempt,
  stats: ModelStatusInputs,
): RealModelStatusState {
  const observedAt = attempt.observedAt.toISOString();
  // A delayed telemetry writer must never undo a newer observation.
  if (previous && previous.observedAt > observedAt) return previous;
  const channelFailureAt =
    attempt.outcome === "failure" && attempt.channelFailure
      ? observedAt
      : (previous?.channelFailureAt ?? null);
  const lastSuccessAt =
    attempt.outcome === "success"
      ? observedAt
      : (previous?.lastSuccessAt ?? null);
  const channelInterrupted =
    attempt.outcome === "success"
      ? false
      : attempt.channelFailure === true ||
        previous?.channelInterrupted === true;
  return {
    ...stats,
    observedAt,
    channelFailureAt,
    lastSuccessAt,
    channelInterrupted,
    stabilityStatus: channelInterrupted
      ? "interrupted"
      : classifyModelStability(stats),
  };
}

/** After a hard outage, measure recovery on attempts after that outage. */
export function recoveredChannelSince(
  previous: RealModelStatusState | null,
  attempt: ModelStatusAttempt,
): Date | null {
  if (
    !previous?.channelFailureAt ||
    (attempt.outcome === "failure" && attempt.channelFailure)
  )
    return null;
  const lastSuccess =
    attempt.outcome === "success"
      ? attempt.observedAt.toISOString()
      : previous.lastSuccessAt;
  return lastSuccess && lastSuccess > previous.channelFailureAt
    ? new Date(previous.channelFailureAt)
    : null;
}
