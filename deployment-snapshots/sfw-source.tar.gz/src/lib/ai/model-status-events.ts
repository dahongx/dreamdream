/** Refresh operational metadata only; this never sends a model request. */
export const MODEL_STATUS_REFRESH_EVENT = "nimir:model-status-refresh";
