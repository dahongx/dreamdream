import postcss from "postcss";

/**
 * Recover the author's reply typography and chat-control skin from a Mufy
 * card's own opening component.
 *
 * Two channels were silently lost at import, and both show up on the same card:
 *
 * 1. Reply typography. The reply DOM uses `.beautified-text-container-no-lines`,
 *    while cards ship only the base `.beautified-text-container` rule. Mufy's
 *    own beautifier injects the `-no-lines` variant at runtime, so it never
 *    reaches an export. Matching on the literal class name dropped the whole
 *    block and replies fell back to host typography — one card visibly
 *    rendering two different typefaces above and below its divider.
 *
 * 2. Control skin. Cards paint the chat chrome with bare `button` /
 *    `input, textarea, select` rules. Dearm's whitelist blocks bare tags by
 *    design, so the skin never reached the host and the platform default
 *    showed through.
 *
 * Everything here is derived from the card's own public component content; no
 * prompt, stored-message or host CSS is read or mutated.
 */

const CONTAINER = /\.beautified-text-container(?![\w-])/;
const CONTAINER_ANY = /\.beautified-text-container(?:-no-lines)?(?![\w-])/;

/** True when the selector addresses the author's text container at all. */
function targetsContainer(selector: string): boolean {
  return CONTAINER_ANY.test(selector);
}

/**
 * Rewrite a selector so it addresses the reply bubble root instead of the
 * author's own container element.
 *
 * Replies never carry `.beautified-text-container` — that class only exists in
 * the source page's markup, and the variant suffix is added by Mufy's runtime.
 * Substituting the bare `body` keyword is what the whitelist already treats as
 * "the scope root", so `body p` becomes `<bubble> p` once rescoped.
 */
function toRootSelector(selector: string): string | null {
  const parts = selector
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);
  const out: string[] = [];
  for (const part of parts) {
    if (!targetsContainer(part)) continue;
    out.push(part.replace(/\.beautified-text-container(?:-no-lines)?(?![\w-])/g, "body"));
  }
  return out.length ? [...new Set(out)].join(", ") : null;
}

/**
 * The author's container rule describes Mufy's page shell as much as its text:
 * padding, margins and a background tuned to the surrounding card. Only the
 * type treatment travels — the reply bubble already owns its own box.
 */
const ROOT_DECLARATION = /^(?:color|font(?:-[\w-]+)?|line-height|letter-spacing|word-spacing|word-break|overflow-wrap|white-space|text-align|text-indent|text-shadow|text-transform|-webkit-text-fill-color|-webkit-text-stroke(?:-[\w-]+)?)$/i;

/**
 * Host blocks that declare their own `font-family`, and why only narration is here.
 *
 * Inherited type from the container is not enough: the platform sets a body font
 * directly on these blocks, and an explicit declaration on the child always beats
 * the value inherited from the container. So the author's type has to be restated
 * on each block that opts out.
 *
 * The bubble is deliberately excluded. On the source the two are different type,
 * not the same type in different boxes: the text container sets a serif at 1.7
 * for prose, while the bubble rule sets `-apple-system …` at 1.5 at 13px. The
 * bubble is the character *speaking* — the card draws it in the platform's UI
 * face. Copying the prose face onto it made every spoken line read as narration
 * that happened to sit inside a rectangle.
 */
const PROSE_TARGETS = [".nj_message_narration"];

/**
 * Paragraph-level text treatment the author wrote as `p`.
 *
 * Replies interleave raw `p` prose with the semantic `div` blocks above, so the
 * same treatment has to reach both or the column alternates between indented
 * and flush-left. Only text treatment travels; spacing stays the host's.
 */
const PARAGRAPH_TREATMENT = /^(?:text-indent|text-align|text-shadow|text-transform|letter-spacing|word-spacing|font(?:-[\w-]+)?|line-height|color)$/i;
const PARAGRAPH_SELECTOR = /^body\s+(?:p|li)(?:[\s,>+~].*)?$/i;

/**
 * Source-platform speech bubble classes, mapped onto the host's semantic block.
 *
 * The card paints its dialogue in bordered bubbles via `.message-outgoing` /
 * `.message-incoming` / `.message-content`. Those are the source platform's own
 * class names and never survive into Dearm's markup, so every one of those rules
 * matched nothing and speech rendered as bare text. `.nj_ai_message_bubble` is
 * the published host selector for exactly that block.
 */
const SPEECH_TARGET = ".nj_ai_message_bubble";
/**
 * Only the two bubble classes.
 *
 * `.message-timestamp` and `.message-container` are source-only furniture: the
 * timestamp rule right-aligns text, and the container rule turns the block into
 * a flex column with its own padding. Mapping them here shipped both onto the
 * bubble, which right-aligned every line and undid the authored box.
 */
const SPEECH_SOURCE = /\.message-(?:outgoing|incoming)\b/;

/**
 * The author's bubble selectors, side-classified.
 *
 * A card writes the same box four ways because it cannot know which of them the
 * platform will emit: the semantic pair (`.message-outgoing` / `.message-incoming`),
 * a generic structural match (`.relative.inline-block[class*="bg-"]`), and the two
 * exact bubble fills it knows about. Only the *characters* variants belong on a
 * Dearm AI bubble; the player's variants would repaint it in the player's colour.
 */
const SPEECH_PLAYER = [
  /^\.message-incoming\b/,
  /\[class\*=["']bg-\[#e8bec3\]["']\]/,
];

/**
 * What the bubble keeps.
 *
 * The authored frame carries two unrelated things at once: the *look* of the box
 * (border, radius, padding, shadow, type) and its *placement* against an avatar
 * the card pinned with `position: absolute; left: -52px`. Dearm places the avatar
 * in the flex row instead, so the source's `margin-left: auto` would shove the
 * bubble away from its own avatar and leave a gap. Placement is dropped; the
 * appearance travel.
 */
const SPEECH_PROPERTY =
  /^(?:border(?:-[\w-]+)?|border-radius|box-shadow|backdrop-filter|-webkit-backdrop-filter|background(?:-[\w-]+)?|color|padding(?:-[\w-]+)?|font(?:-[\w-]+)?|line-height|letter-spacing|text-shadow|text-indent|text-align|white-space|word-break|overflow-wrap|width|max-width|min-width|display|position|top|right|bottom|left|content|opacity|transform|transition)$/i;

function isSpeechSelector(selector: string): boolean {
  const s = selector.trim();
  if (!s) return false;
  if (/^\.message-(?:outgoing|incoming)\b/.test(s)) return true;
  // Generic bubble match and the two known fills.
  if (/^\.relative\.inline-block\[class\*=["'](?:bg-|_message_)/.test(s)) return true;
  return false;
}

/**
 * Rewrite one authored bubble selector onto the host bubble, keeping only the
 * tail that still means something here.
 *
 * Returns `null` when the selector is the player's side or a descendant rule
 * (`.message-outgoing .message-timestamp`) — those describe furniture that does
 * not exist in Dearm's markup, so mapping them would invent styles.
 */
function toSpeechSelector(selector: string): string | null {
  const s = selector.trim();
  if (!isSpeechSelector(s)) return null;
  if (SPEECH_PLAYER.some((re) => re.test(s))) return null;
  // A descendant or child selector describes furniture inside the box
  // (`.message-outgoing .message-timestamp`), not the box. Mapping it onto the
  // bubble would paint the timestamp's muted colour across the whole line.
  if (/[\s>+~]/.test(s)) return null;
  if (/^\.message-(?:outgoing|incoming)\b/.test(s)) {
    const head = /^\.message-(?:outgoing|incoming)\b/.exec(s)![0];
    const rest = s.slice(head.length);
    return rest ? `${SPEECH_TARGET}${rest}` : SPEECH_TARGET;
  }
  // Structural matches carry no meaningful tail beyond a pseudo-element.
  const pseudo = /::(?:after|before)\b/.exec(s);
  return pseudo ? `${SPEECH_TARGET}${pseudo[0]}` : SPEECH_TARGET;
}

/**
 * Published host controls an author's generic button skin should paint.
 *
 * The author wrote `button` once and meant "my chat chrome" — on the source
 * platform that was the whole toolbar. Here the same intent has to name each
 * control, including the ones Dearm adds that the author never knew about
 * (mask, currency switcher, model label), so the whole family stays uniform.
 */
const BUTTON_TARGETS = [
  "nj_chat_input_replay_btn",
  "nj_mask_btn",
  "nj_chat_input_model_btn",
  "nj_currency_switcher",
  "nj_back_button",
  "nj_mobile_drawer_btn",
  "nj_review_btn",
  "nj_header_more_btn",
  "nj_stage_adjust_btn",
] as const;

/**
 * Text fields: the composer shell only.
 *
 * `#nj_chat_input_box` is the wrapper id; the inner textarea is border-0 by
 * contract so the composer reads as one frame. Painting the authored border on
 * both produced a box inside a box — the source page's `textarea` rule only
 * ever addressed its single field, so mapping it to both invents a second
 * frame the author never drew.
 */
const FIELD_TARGETS = ["nj_chat_input_box"] as const;

/**
 * Id repeated this many times.
 *
 * The whitelist ends every scoped stylesheet with a platform reset that repeats
 * each control id 10× so it can never lose to a creator stylesheet. Our
 * recovered skin is the author's own chrome, not a stray creator override, so
 * it has to outrank that reset: 12 ids beat 10 on specificity regardless of
 * source order. Repeating an id is legal CSS and is the same technique the
 * whitelist itself uses.
 */
const ID_BOOST = 12;

function boostId(id: string): string {
  return `#${id}`.repeat(ID_BOOST);
}

/**
 * Text fields take the authored frame only.
 *
 * Border only, never padding. The source page put 8px of padding on its single
 * `<textarea>`; the host puts that on the inner textarea and keeps the wrapper
 * flush. Applying it to the wrapper too inflated the composer from 53px to
 * 72px, which is exactly the "input box is huge" the other cards never showed.
 * Background is skipped for the same reason it was on the source: the platform
 * shell owns the fill, and the author's light colour was already overridden.
 */
const FIELD_PROPERTY = /^(?:border(?:-[\w-]+)?|outline(?:-[\w-]+)?)$/i;

const CONTROL_TAG = /^(?:button|input|textarea|select)$/i;

interface MappedSelector {
  selector: string;
  field: boolean;
  /** Speech-bubble rule: the box the author drew around spoken lines. */
  speech?: boolean;
}

/** Map one authored selector onto the host controls it actually means. */
function mapControlSelector(selector: string): MappedSelector[] {
  const trimmed = selector.trim();
  if (!trimmed || /\bnj_/.test(trimmed)) return [];

  // Speech bubbles: the source platform's own class names.
  //
  // Which side is which is settled by the card itself, not by the English word.
  // This card's stylesheet labels them inline: `/* 用户消息 (incoming) */` paints
  // the pale `#B0A8C8` frame inset from the left, and `/* AI消息 (outgoing) */`
  // paints the deeper `#7C6F9A` frame with a 4px top-right corner. The character
  // speaks on the outgoing side; the player replies on the incoming side. An
  // earlier version read "outgoing" as the player and dropped it, which shipped
  // the player's pale left-inset box as the AI bubble — the one visibly wrong
  // frame on this card. Outgoing is the character, so it is the one we keep.
  if (isSpeechSelector(trimmed) || SPEECH_SOURCE.test(trimmed)) {
    return [{ selector: toSpeechSelector(trimmed) ?? "", field: false, speech: true }].filter(
      (entry) => entry.selector,
    );
  }

  const bare = trimmed.replace(/:not\([^()]*\)/g, "").trim();
  const head = /^([a-zA-Z][\w-]*)([\s\S]*)$/.exec(bare);
  if (!head || !CONTROL_TAG.test(head[1])) return [];

  // Button-shaped controls: `<button>`, `input[type=button|submit|reset]`.
  const isButtonShaped =
    /^button$/i.test(head[1]) ||
    /\[type\s*=\s*["']?(?:button|submit|reset)/i.test(trimmed);
  // Keep the authored state/pseudo tail verbatim so :hover, ::before and the
  // rest land on the control they were written for. The input type attribute
  // only selected the source element, so it must not survive the rewrite.
  const tail = head[2].replace(/\[type\s*=\s*["'][^"']*["']\]/gi, "");

  if (isButtonShaped) {
    return BUTTON_TARGETS.map((id) => ({ selector: `${boostId(id)}${tail}`, field: false }));
  }
  return FIELD_TARGETS.map((id) => ({ selector: `${boostId(id)}${tail}`, field: true }));
}

const KEYFRAMES_PARENT = /keyframes$/;

function parentAtRuleName(rule: postcss.Rule): string {
  const parent = rule.parent;
  return parent && parent.type === "atrule" ? parent.name.toLowerCase() : "";
}

function adaptTypography(css: string): string {
  let root: postcss.Root;
  try {
    root = postcss.parse(css);
  } catch {
    return "";
  }
  // Clones are appended after the walk: a clone's selector no longer targets the
  // container, so walking it would delete the rule that was just created.
  const proseRules: postcss.Rule[] = [];
  root.walkRules((rule) => {
    if (KEYFRAMES_PARENT.test(parentAtRuleName(rule))) {
      rule.remove();
      return;
    }
    const rewritten = toRootSelector(rule.selector);
    if (rewritten === null) {
      rule.remove();
      return;
    }
    rule.selector = rewritten;
    // `body` alone is the bubble root: trim it to the type treatment, and give
    // the same treatment to the host blocks that set their own body font.
    if (rule.selectors.every((part) => part === "body")) {
      rule.walkDecls((decl) => {
        if (!ROOT_DECLARATION.test(decl.prop)) decl.remove();
      });
      if (!rule.nodes || rule.nodes.length === 0) {
        rule.remove();
        return;
      }
      const cloned = rule.clone();
      cloned.selector = PROSE_TARGETS.join(", ");
      proseRules.push(cloned);
      return;
    }
    // `body p` / `body li` stay as they are. The whitelist rewrites the `body`
    // head to the scope root, which is exactly what a reply paragraph is: the
    // source put its prose in `p` elements under the text container, and the
    // reply keeps those elements. Dropping the rule here was why the opening
    // above the divider was indented while the reply below it sat flush left.
    //
    // The same paragraph treatment also has to reach the semantic blocks, which
    // are `div`s rather than `p`s. A reply alternates raw `p` prose with
    // `nj_message_narration` and `nj_ai_message_bubble`, so covering only `p`
    // produced exactly the alternating indented/flush-left look.
    if (rule.selectors.every((part) => PARAGRAPH_SELECTOR.test(part))) {
      const treatment = rule.clone();
      treatment.walkDecls((decl) => {
        if (!PARAGRAPH_TREATMENT.test(decl.prop)) decl.remove();
      });
      if (!treatment.nodes || treatment.nodes.length === 0) {
        return;
      }
      treatment.selector = PROSE_TARGETS.join(", ");
      proseRules.push(treatment);
    }
  });
  for (const rule of proseRules) root.append(rule);
  root.walkAtRules((atRule) => {
    if (!/^(?:media|supports)$/i.test(atRule.name)) {
      atRule.remove();
      return;
    }
    if (atRule.nodes && atRule.nodes.length === 0) atRule.remove();
  });
  const value = root.toString().trim();
  return /\{/.test(value) ? value : "";
}

function adaptControls(css: string): string {
  let root: postcss.Root;
  try {
    root = postcss.parse(css);
  } catch {
    return "";
  }
  root.walkRules((rule) => {
    if (KEYFRAMES_PARENT.test(parentAtRuleName(rule))) return;
    const mapped = rule.selectors.flatMap(mapControlSelector);
    if (!mapped.length) {
      rule.remove();
      return;
    }
    rule.selectors = [...new Set(mapped.map((entry) => entry.selector))];
    if (mapped.every((entry) => entry.speech)) {
      rule.walkDecls((decl) => {
        if (!SPEECH_PROPERTY.test(decl.prop)) decl.remove();
      });
      if (!rule.nodes || rule.nodes.length === 0) rule.remove();
      return;
    }
    if (mapped.every((entry) => entry.field)) {
      rule.walkDecls((decl) => {
        if (!FIELD_PROPERTY.test(decl.prop)) decl.remove();
      });
      if (!rule.nodes || rule.nodes.length === 0) rule.remove();
    }
  });
  root.walkAtRules((atRule) => {
    if (!/^(?:media|supports|keyframes)$/i.test(atRule.name)) {
      atRule.remove();
      return;
    }
    if (atRule.nodes && atRule.nodes.length === 0) atRule.remove();
  });
  // A keyframe only earns its place while a surviving rule still names it.
  const retained = root.toString();
  root.walkAtRules((atRule) => {
    if (!/keyframes$/i.test(atRule.name)) return;
    const name = atRule.params.trim();
    if (!name || !new RegExp(`\\b${name}\\b`).test(retained)) atRule.remove();
  });
  const value = root.toString().trim();
  return /\{/.test(value) ? value : "";
}

export interface MufyAuthoredReplySkin {
  /** Reply container typography, already covering the `-no-lines` variant. */
  typography: string;
  /** Authored button and field frame, rewritten onto published host ids. */
  controls: string;
  /** Combined block ready for `sanitizeAndScopeCss`. */
  css: string;
}

/**
 * Host body defaults that must not leak into an imported card's prose.
 *
 * Dearm sets `letter-spacing: 0.02em` on `body` for its own typographic feel;
 * the source platform leaves it `normal`. At the card's 13px that is 0.32px of
 * extra tracking per character, which widens every line and lets fewer
 * characters fit — the reply reads visibly looser than the same paragraph on
 * the source even though size, face, and leading all match. These are inherited
 * properties, so any block that restates the author's type has to reset them
 * explicitly; stating one without the others moves the mismatch sideways.
 */
const INHERITED_RESET = `
:root {
  letter-spacing: normal;
  word-spacing: normal;
  font-weight: 400;
  font-style: normal;
  text-transform: none;
  text-decoration: none;
}
.nj_message_narration,
.nj_ai_message_bubble {
  letter-spacing: normal;
  word-spacing: normal;
  font-style: normal;
  text-transform: none;
}`;

/**
 * Whether the card draws its dialogue as speech bubbles at all.
 *
 * Across every migrated card the rule is absolute: a card that defines
 * `.message-incoming` / `.message-outgoing` renders each spoken line in a
 * bordered bubble with the character's avatar beside it, and a card that does
 * not renders plain paragraphs with no avatars. The two never mix, so this one
 * signal decides both — the bubble skin and the avatar.
 */
export function hasMufyAuthoredSpeechSkin(
  components: ReadonlyArray<{ content: string }>,
): boolean {
  for (const { content } of components) {
    if (!content || content.length > 2_097_152) continue;
    for (const match of content.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)) {
      const clean = match[1].replace(/\/\*[\s\S]*?\*\//g, "");
      if (SPEECH_SOURCE.test(clean)) return true;
    }
  }
  return false;
}

/**
 * Extract the author's reply skin. Returns empty strings unless the card
 * actually ships Mufy's `.beautified-text-container` block — that marker is
 * what identifies the card as Mufy-beautified, so ordinary creator CSS never
 * gets rerouted through this path.
 */
export function collectMufyAuthoredReplySkin(
  components: ReadonlyArray<{ content: string }>,
): MufyAuthoredReplySkin {
  const typography: string[] = [];
  const controls: string[] = [];
  let isMufyCard = false;

  for (const { content } of components) {
    if (!content || content.length > 2_097_152) continue;
    for (const match of content.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)) {
      const css = match[1];
      if (css.length > 32_768) continue;
      const clean = css.replace(/\/\*[\s\S]*?\*\//g, "");
      if (/<script/i.test(clean)) continue;
      if (CONTAINER.test(clean)) {
        isMufyCard = true;
        const adapted = adaptTypography(css);
        if (adapted) typography.push(adapted);
        continue;
      }
      if (!/(?:^|[{};,]\s*)(?:button|input|textarea|select)\b/i.test(clean)) continue;
      const adapted = adaptControls(css);
      if (adapted) controls.push(adapted);
    }
  }

  if (!isMufyCard) return { typography: "", controls: "", css: "" };
  // The reset rides the typography channel, which is the one the chat page
  // actually renders. Putting it only on `css` left it unreachable: the page
  // consumes `typography` (reply blocks) and `controls` (chrome), never `css`.
  const typographyCss = [INHERITED_RESET, ...typography].join("\n").trim();
  return {
    typography: typographyCss,
    controls: controls.join("\n"),
    css: [typographyCss, ...controls].join("\n").trim(),
  };
}
