"use client";
import { useActionState, useState } from "react";
import { btnPrimary, btnSecondary } from "@/components/ui/button";
import { fieldCls } from "@/components/ui/field";
import { referralCopy } from "@/i18n/referrals";
import type { Locale } from "@/i18n/types";
import { saveReferralSettings } from "@/lib/referrals/actions";
import type { ReferralSettings } from "@/lib/referrals/service";
import { copyTextToClipboard } from "@/lib/util/clipboard";

export function CopyReferral({
  code,
  locale,
}: {
  code: string;
  locale: Locale;
}) {
  const t = referralCopy(locale);
  const [copied, setCopied] = useState<boolean | null>(null);
  return (
    <div className="flex flex-wrap items-center gap-[var(--space-md)]">
      <span className="break-all text-text-secondary">
        {t.code}: {code}
      </span>
      <button
        type="button"
        className={btnSecondary}
        onClick={async () => {
          const url = new URL("/api/referrals/visit", window.location.origin);
          url.searchParams.set("code", code);
          setCopied(await copyTextToClipboard(url.toString()));
        }}
      >
        {t.copy}
      </button>
      {copied !== null && (
        <output
          className={`text-sm ${copied ? "text-semantic-success" : "text-semantic-error"}`}
        >
          {copied ? t.copied : t.copyFailed}
        </output>
      )}
    </div>
  );
}
export function ReferralSettingsForm({
  settings,
  locale,
}: {
  settings: ReferralSettings;
  locale: Locale;
}) {
  const t = referralCopy(locale);
  const [result, action, pending] = useActionState(saveReferralSettings, null);
  return (
    <form action={action} className="flex flex-col gap-[var(--space-md)]">
      <label className="flex items-center gap-[var(--space-sm)]">
        <input
          type="checkbox"
          name="enabled"
          defaultChecked={settings.enabled}
        />
        {t.enabled}
      </label>
      <div className="grid gap-[var(--space-md)] sm:grid-cols-2">
        <label className="flex flex-col gap-[var(--space-xs)]">
          {t.inviterAmount}
          <input
            className={fieldCls}
            name="inviter"
            type="number"
            min={0}
            max={10000}
            required
            defaultValue={settings.inviter_amount}
          />
        </label>
        <label className="flex flex-col gap-[var(--space-xs)]">
          {t.inviteeAmount}
          <input
            className={fieldCls}
            name="invitee"
            type="number"
            min={0}
            max={10000}
            required
            defaultValue={settings.invitee_amount}
          />
        </label>
      </div>
      <button
        disabled={pending}
        className={`${btnPrimary} self-start`}
        type="submit"
      >
        {pending ? t.saving : t.save}
      </button>
      {result && (
        <output
          className={
            result.ok ? "text-semantic-success" : "text-semantic-error"
          }
        >
          {result.ok ? t.saved : t.error}
        </output>
      )}
    </form>
  );
}
