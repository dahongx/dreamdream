import { sql } from "drizzle-orm";
import { referralCopy } from "@/i18n/referrals";
import { getRequestLocale } from "@/i18n/server";
import { getCurrentUserId } from "@/lib/auth/current-user";
import { db } from "@/lib/db/client";
import {
  getReferralCode,
  getReferralSettings,
  type ReferralClaim,
} from "@/lib/referrals/service";
import { CopyReferral, ReferralSettingsForm } from "./ReferralControls";

export async function ReferralSection({ admin = false, hideTitle = false }: { admin?: boolean; hideTitle?: boolean }) {
  const userId = await getCurrentUserId();
  const locale = await getRequestLocale();
  const t = referralCopy(locale);
  if (admin) {
    const [me] = await db.execute<{ role: string }>(
      sql`SELECT role FROM users WHERE id=${userId}::uuid`,
    );
    if (me?.role !== "admin") return null;
  }
  const settings = await getReferralSettings();
  const rows = await db.execute<
    ReferralClaim & { inviter_name: string | null; invitee_name: string | null }
  >(sql`
  SELECT c.*,a.username AS inviter_name,b.username AS invitee_name FROM referral_claims c
  LEFT JOIN users a ON a.id=c.inviter_id LEFT JOIN users b ON b.id=c.invitee_id
  WHERE ${admin ? sql`true` : sql`c.inviter_id=${userId}::uuid OR c.invitee_id=${userId}::uuid`}
  ORDER BY c.created_at DESC LIMIT 100`);
  if (!admin && !settings.enabled && !rows.length) return null;
  const code =
    settings.enabled && !admin ? await getReferralCode(userId) : null;
  return (
    <section className="glass-card-static flex min-w-0 flex-col gap-[var(--space-lg)] p-[var(--space-lg)]">
      {!hideTitle && <h2 className="font-display-zh text-xl text-text-primary">
        {admin ? t.admin : t.title}
      </h2>}
      {admin ? (
        <ReferralSettingsForm settings={settings} locale={locale} />
      ) : (
        <>
          <p className="text-text-secondary">
            {settings.enabled
              ? t.rule
                  .replace("{a}", String(settings.inviter_amount))
                  .replace("{b}", String(settings.invitee_amount))
              : t.paused}
          </p>
          {code && <CopyReferral code={code} locale={locale} />}
        </>
      )}
      <details>
        <summary className="cursor-pointer py-[var(--space-sm)] text-text-secondary">
          {t.records} ({rows.length}
          {rows.length === 100 ? "+" : ""})
        </summary>
        {!rows.length ? (
          <p className="py-[var(--space-md)] text-text-secondary">{t.empty}</p>
        ) : (
          <ul className="divide-y divide-border-subtle">
            {rows.map((row) => (
              <li
                key={row.id}
                className="flex flex-col gap-[var(--space-xs)] py-[var(--space-md)] text-sm"
              >
                <div className="flex flex-wrap justify-between gap-[var(--space-sm)]">
                  <span>
                    {admin
                      ? `${t.inviter}: ${row.inviter_name ?? "—"} · ${t.invitee}: ${row.invitee_name ?? t.anonymous}`
                      : row.inviter_id === userId
                        ? t.inviterReward
                        : t.inviteeReward}
                  </span>
                  <span>{t[row.status]}</span>
                </div>
                <span className="text-text-secondary">
                  {new Date(row.created_at).toLocaleString(locale, {
                    timeZone: "Asia/Shanghai",
                  })}{" "}
                  ·{" "}
                  {admin
                    ? `${t.inviter}: ${row.inviter_amount} ${t.silver} · ${t.invitee}: ${row.invitee_amount} ${t.silver}`
                    : `${
                        row.inviter_id === userId
                          ? row.inviter_amount
                          : row.invitee_amount
                      } ${t.silver}`}
                </span>
                {admin && (
                  <>
                    <span className="break-all text-text-secondary">
                      {t.source}: {row.source} · {row.code}
                    </span>
                    <span className="break-all text-text-secondary">
                      {t.id}: {row.id} {row.reason ?? ""}
                    </span>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
      </details>
    </section>
  );
}
