"use client";
import { createContext } from 'react';
/** Already-public opening component CSS; supplied per chat, never a global registry. */
export const MufySharedComponentStyleContext=createContext('');
/** Per-chat source compatibility, including normal-UI imported components. */
export const MufyNativeSourceContext=createContext(false);
/** Opt-in only for a verified, fixed source-font dependency. */
export const MufyOriginalTitleFontContext=createContext(false);
/**
 * The card's own reply typography, already scoped to the reply bubble root.
 *
 * Separate from the shared component style: that one only carries the public
 * widget blocks (fire terminal, state panels) and never the author's text
 * container, so a card could show the author's serif in its opening and the
 * host sans in every reply.
 */
export const MufyReplyTypographyContext=createContext('');

/**
 * Whether the card draws dialogue as bubbles with the character avatar beside
 * each spoken line.
 *
 * Derived from the card's own `.message-incoming` / `.message-outgoing` rules.
 * Across every migrated card those two go together — a card either has bubble
 * plus avatar throughout, or plain paragraphs with neither.
 */
export const MufySpeechAvatarContext=createContext(false);
