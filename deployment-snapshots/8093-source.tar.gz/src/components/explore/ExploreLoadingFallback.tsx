import { ExploreStoryOpening } from "@/components/explore/ExploreStoryOpening";
import { getRequestLocale } from "@/i18n/server";
import { RouteLoadingLogo } from "@/components/ui/RouteLoadingLogo";
import type { Dict } from "@/i18n/types";

type ExploreLoadingFallbackProps = {
  dict: Dict;
};

export async function ExploreLoadingFallback({ dict }: ExploreLoadingFallbackProps) {
  const locale = await getRequestLocale();
  const skeletonCards = Array.from({ length: 10 }, (_, i) => i);

  return (
    <div className="explore-page nj-c-home nj-home-compact mx-auto w-full max-w-[var(--content-max-width)] px-[var(--page-px)] py-[var(--page-py)]">
      <RouteLoadingLogo label={dict.shell.loading} overlay />
      <header className="explore-hero relative mb-[var(--space-lg)] overflow-hidden">
        <ExploreStoryOpening locale={locale} />
      </header>

      <div aria-hidden="true" className="nj-home-loading-controls">
        <div className="nj-home-loading-search animate-pulse rounded-[var(--radius-sm)] bg-surface-glass/50" />
        <div className="nj-home-loading-tabs animate-pulse rounded-[var(--radius-pill)] bg-surface-glass/40" />
      </div>
      <div aria-hidden="true" className="nj-home-loading-tags animate-pulse rounded-[var(--radius-sm)] bg-surface-glass/40" />

      <output
        aria-live="polite"
        aria-busy="true"
        className="nj-moonrise-grid grid grid-cols-2 gap-[var(--space-md)] sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5"
      >
        <span className="sr-only">{dict.shell.loading}</span>
        {skeletonCards.map((i) => (
          <div
            key={i}
            className="nj-home-loading-card aspect-[4/5] animate-pulse rounded-[var(--radius-md)] border border-border-subtle bg-surface-glass/50"
            style={{ animationDelay: `${(i % 5) * 120}ms` }}
          />
        ))}
      </output>
    </div>
  );
}
