import { and, eq, inArray } from "drizzle-orm";
import { ChevronRight } from "lucide-react";
import Link from "next/link";
import { ImageWithFallback } from "@/components/ui/ImageWithFallback";
import { getRequestI18n } from "@/i18n/server";
import { db } from "@/lib/db/client";
import { characters } from "@/lib/db/schema";
import { listRecentSessionsForUser } from "@/lib/sessions/queries";
import { firstChar } from "@/lib/util/first-char";
import { previewSnippet } from "@/lib/util/preview-text";

/** Private, current-user resume links. No writes or synthetic conversations. */
export async function ExploreRecentChats({ userId, showNsfw }: { userId: string; showNsfw: boolean }) {
  const [{ dict, locale }, sessions] = await Promise.all([
    getRequestI18n(), listRecentSessionsForUser(userId),
  ]);
  const accessible = sessions.filter(s => s.accessible && !s.characterDeleted && s.characterId);
  if (!accessible.length) return null;
  const allowed = showNsfw ? null : new Set((await db.select({ id: characters.id })
    .from(characters).where(and(inArray(characters.id, accessible.map(s => s.characterId!)), eq(characters.nsfw, false))))
    .map(c => c.id));
  const seen = new Set<string>();
  const recent = accessible.filter(s => {
    const id = s.characterId!;
    if ((allowed && !allowed.has(id)) || seen.has(id)) return false;
    seen.add(id); return true;
  }).slice(0, 3);
  if (!recent.length) return null;
  const date = new Intl.DateTimeFormat(locale, { month: "short", day: "numeric", timeZone: "Asia/Shanghai" });
  return (
    <section className="nj-home-recent" aria-labelledby="nj-home-recent-title">
      <div className="nj-home-section-heading">
        <h2 id="nj-home-recent-title">{dict.sessions.tabRecent}</h2>
        <Link href="/sessions">{dict.nav.sessions}<ChevronRight size={14} aria-hidden="true" /></Link>
      </div>
      <div className="nj-home-recent-track">
        {recent.map(s => (
          <Link key={s.id} href={`/chat/${s.characterId}`} className="nj-home-recent-card">
            <span className="nj-home-recent-avatar">
              {s.characterAvatarUrl ? <ImageWithFallback src={s.characterAvatarUrl} alt="" loading="lazy" className="h-full w-full object-cover" fallback={<span>{firstChar(s.characterName)}</span>} /> : <span>{firstChar(s.characterName)}</span>}
            </span>
            <span className="nj-home-recent-copy">
              <span className="nj-home-recent-name">{s.characterName}</span>
              <span className="nj-home-recent-preview">{previewSnippet(s.previewContent?.replace(/<(script|style)\b[^>]*>[\s\S]*?<\/\1>/gi, ""), 42) ?? dict.sessions.previewUnavailable}</span>
              <time dateTime={new Date(s.lastMessageAt).toISOString()}>{date.format(new Date(s.lastMessageAt))}</time>
            </span>
            <ChevronRight className="nj-home-recent-chevron" size={16} aria-hidden="true" />
          </Link>
        ))}
      </div>
    </section>
  );
}
