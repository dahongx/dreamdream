export const HOME_COPY = {
  "zh-TW": { title: "與你未完的故事", intro: "在這裡，遇見另一個世界的他，與未完成的故事再次相逢。", note: "與虛構的靈魂，\n讀一場真實的心動。", recommend: "為你推薦" },
  "ja-JP": { title: "あなたと紡ぐ、物語の続き", intro: "もうひとつの世界の誰かと、まだ終わらない物語を。", note: "架空の誰かと、\n本当のときめきを。", recommend: "あなたへのおすすめ" },
  "th-TH": { title: "เรื่องราวของเราที่ยังไม่จบ", intro: "พบใครสักคนจากอีกโลก แล้วสานต่อเรื่องราวที่ยังค้างอยู่", note: "กับตัวตนในจินตนาการ\nและความรู้สึกที่เป็นจริง", recommend: "แนะนำสำหรับคุณ" },
  en: { title: "Your unfinished stories", intro: "Meet someone from another world. Return to a story still unfolding.", note: "Imagined souls.\nSomething real to feel.", recommend: "For you" },
} as const;
