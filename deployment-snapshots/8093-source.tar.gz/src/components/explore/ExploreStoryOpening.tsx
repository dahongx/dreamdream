import type { Locale } from "@/i18n/types";
import { HOME_COPY } from "./story-copy";

/** One opening for both the resolved page and its route loading state. */
export function ExploreStoryOpening({ locale }: { locale: Locale }) {
  const home = HOME_COPY[locale];
  return <>
    <div className="explore-hero-copy">
      <h1 className="hero-title hero-title-xl">{home.title}</h1>
      <p className="explore-hero-mood">{home.intro}</p>
    </div>
    <aside className="nj-c-hero-note">
      <span className="nj-c-hero-botanical" aria-hidden="true" />
      <p><span className="nj-c-signature">寄情</span>{home.note}</p>
    </aside>
  </>;
}
