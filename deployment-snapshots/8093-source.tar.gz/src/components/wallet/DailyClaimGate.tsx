"use client";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { useDialog } from "@/components/ui/DialogProvider";
import { useI18n } from "@/i18n/client";
import {
  createDailyClaimClient,
  type DailyClaimResponse,
} from "@/lib/currency/daily-claim-client";

export function DailyClaimGate({ userId }: { userId: string }) {
  const { alert } = useDialog();
  const { dict } = useI18n();
  const router = useRouter();
  useEffect(() => {
    let active = true;
    const claim = createDailyClaimClient(userId, async (id) => {
      const response = await fetch("/api/currency/claim-daily", {
        method: "POST",
        headers: { "x-dearm-user-id": id },
        signal: AbortSignal.timeout(15000),
      });
      if (!response.ok) throw Error("DAILY_CLAIM_FAILED");
      const data: unknown = await response.json();
      if (
        !data ||
        typeof data !== "object" ||
        !("claimed" in data) ||
        typeof data.claimed !== "boolean" ||
        !("newBalance" in data) ||
        typeof data.newBalance !== "number" ||
        !("amount" in data) ||
        typeof data.amount !== "number"
      )
        throw Error("DAILY_CLAIM_INVALID_RESPONSE");
      return data as DailyClaimResponse;
    });
    const attempt = async () => {
      if (!active || document.visibilityState === "hidden") return;
      try {
        const result = await claim();
        if (!active || !result?.claimed) return;
        router.refresh();
        await alert({
          title: dict.dailyClaim.title,
          body: (
            <p>
              <span className="font-mono font-semibold text-currency-silver">
                +{result.amount}
              </span>{" "}
              {dict.dailyClaim.bodyArrived}{" "}
              <span className="font-mono font-semibold text-currency-silver">
                {result.newBalance}
              </span>
              {dict.dailyClaim.bodyArrivedSuffix}
            </p>
          ),
          okLabel: dict.dialog.ok,
        });
      } catch {
        /* Retry on focus, reconnect, or the next minute. Server owns idempotency. */
      }
    };
    void attempt();
    const retry = () => {
      void attempt();
    };
    const timer = window.setInterval(retry, 60000);
    window.addEventListener("focus", retry);
    window.addEventListener("online", retry);
    document.addEventListener("visibilitychange", retry);
    return () => {
      active = false;
      window.clearInterval(timer);
      window.removeEventListener("focus", retry);
      window.removeEventListener("online", retry);
      document.removeEventListener("visibilitychange", retry);
    };
  }, [userId, router, alert, dict.dailyClaim, dict.dialog.ok]);
  return null;
}
