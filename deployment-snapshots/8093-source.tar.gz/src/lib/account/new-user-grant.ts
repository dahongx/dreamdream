import { sql } from "drizzle-orm";
import { db } from "@/lib/db/client";
import { hashDeactivatedEmailFromEnv } from "./email-hash";

/** Revoke only the recorded welcome grant, once; never clear later earned balances. */
export async function revokeNewUserGrantIfPreviouslyDeleted(
  userId: string,
  email: string,
  identityCreatedAt: string,
): Promise<boolean> {
  if (!Number.isFinite(Date.parse(identityCreatedAt)))
    throw Error("INVALID_AUTH_CREATION_TIME");
  const hash = hashDeactivatedEmailFromEnv(email);
  return db.transaction(async (tx) => {
    const [hit] = await tx.execute(
      // A failed deletion may leave a fingerprint for the SAME, still-live identity.
      // Only an identity created AFTER the fingerprint is a re-registration.
      sql`SELECT 1 FROM deactivated_email_hashes WHERE email_hash=${hash} AND deactivated_at < ${identityCreatedAt}::timestamptz`,
    );
    if (!hit) return false;
    const [user] = await tx.execute<{
      gold_balance: number;
      silver_balance: number;
    }>(
      sql`SELECT gold_balance,silver_balance FROM users WHERE id=${userId}::uuid FOR UPDATE`,
    );
    if (!user) return false;
    for (const currency of ["gold", "silver"] as const) {
      const [grant] = await tx.execute<{ amount: number }>(
        sql`SELECT coalesce(sum(amount),0)::int AS amount FROM currency_transactions WHERE user_id=${userId}::uuid AND transaction_type='signup_grant' AND currency_type=${currency}`,
      );
      if (!grant || grant.amount <= 0) continue;
      const balance = user[`${currency}_balance`] - grant.amount;
      if (balance < 0) throw Error("WELCOME_GRANT_RECONCILIATION_REQUIRED");
      if (currency === "gold")
        await tx.execute(
          sql`UPDATE users SET gold_balance=${balance},updated_at=now() WHERE id=${userId}::uuid`,
        );
      else
        await tx.execute(
          sql`UPDATE users SET silver_balance=${balance},updated_at=now() WHERE id=${userId}::uuid`,
        );
      await tx.execute(
        sql`INSERT INTO currency_transactions(user_id,transaction_type,currency_type,amount,balance_after,note) VALUES(${userId}::uuid,'signup_grant',${currency},${-grant.amount},${balance},'signup_grant_revoked')`,
      );
    }
    return true;
  });
}
