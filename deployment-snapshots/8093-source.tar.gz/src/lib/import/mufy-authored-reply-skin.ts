import postcss from "postcss";

/**
 * Recover the author's reply typography and chat-control skin from a Mufy
 * card's own opening component.
 *
 * Two channels were silently lost at import, and both show up on the same card:
 *
 * 1. Reply typography. The reply DOM uses `.beautified-text-container-no-lines`,
 *    while cards ship only the base `.beautified-text-container` rule. Mufy's
 *    own beautifier injects the `-no-lines` variant at runtime, so it never
 *    reaches an export. Matching on the literal class name dropped the whole
 *    block and replies fell back to host typography — one card visibly
 *    rendering two different typefaces above and below its divider.
 *
 * 2. Control skin. Cards paint the chat chrome with bare `button` /
 *    `input, textarea, select` rules. Dearm's whitelist blocks bare tags by
 *    design, so the skin never reached the host and the platform default
 *    showed through.
 *
 * Everything here is derived from the card's own public component content; no
 * prompt, stored-message or host CSS is read or mutated.
 */

const CONTAINER = /\.beautified-text-container(?![\w-])/;
const CONTAINER_ANY = /\.beautified-text-container(?:-no-lines)?(?![\w-])/;

/** True when the selector addresses the author's text container at all. */
function targetsContainer(selector: string): boolean {
  return CONTAINER_ANY.test(selector);
}

/**
 * Rewrite a selector so it addresses the reply bubble root instead of the
 * author's own container element.
 *
 * Replies never carry `.beautified-text-container` — that class only exists in
 * the source page's markup, and the variant suffix is added by Mufy's runtime.
 * Substituting the bare `body` keyword is what the whitelist already treats as
 * "the scope root", so `body p` becomes `<bubble> p` once rescoped.
 */
function toRootSelector(selector: string): string | null {
  const parts = selector
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);
  const out: string[] = [];
  for (const part of parts) {
    if (!targetsContainer(part)) continue;
    out.push(part.replace(/\.beautified-text-container(?:-no-lines)?(?![\w-])/g, "body"));
  }
  return out.length ? [...new Set(out)].join(", ") : null;
}

/**
 * The author's container rule describes Mufy's page shell as much as its text:
 * padding, margins and a background tuned to the surrounding card. Only the
 * type treatment travels — the reply bubble already owns its own box.
 */
const ROOT_DECLARATION = /^(?:color|font(?:-[\w-]+)?|line-height|letter-spacing|word-spacing|word-break|overflow-wrap|white-space|text-align|text-indent|text-shadow|text-transform|-webkit-text-fill-color|-webkit-text-stroke(?:-[\w-]+)?)$/i;

/**
 * Host blocks that declare their own `font-family`.
 *
 * Inherited type from the bubble root is not enough: the platform sets a body
 * font directly on the narration and speech blocks, and an explicit declaration
 * on the child always beats the value inherited from the container. Restating
 * the author's type on these blocks is what makes the reply match the opening.
 */
const PROSE_TARGETS = [".nj_message_narration", ".nj_ai_message_bubble"];

/**
 * Paragraph-level text treatment the author wrote as `p`.
 *
 * Replies interleave raw `p` prose with the semantic `div` blocks above, so the
 * same treatment has to reach both or the column alternates between indented
 * and flush-left. Only text treatment travels; spacing stays the host's.
 */
const PARAGRAPH_TREATMENT = /^(?:text-indent|text-align|text-shadow|text-transform|letter-spacing|word-spacing|font(?:-[\w-]+)?|line-height|color)$/i;
const PARAGRAPH_SELECTOR = /^body\s+(?:p|li)(?:[\s,>+~].*)?$/i;

/**
 * Source-platform speech bubble classes, mapped onto the host's semantic block.
 *
 * The card paints its dialogue in bordered bubbles via `.message-outgoing` /
 * `.message-incoming` / `.message-content`. Those are the source platform's own
 * class names and never survive into Dearm's markup, so every one of those rules
 * matched nothing and speech rendered as bare text. `.nj_ai_message_bubble` is
 * the published host selector for exactly that block.
 */
const SPEECH_TARGET = ".nj_ai_message_bubble";
/**
 * Only the two bubble classes.
 *
 * `.message-timestamp` and `.message-container` are source-only furniture: the
 * timestamp rule right-aligns text, and the container rule turns the block into
 * a flex column with its own padding. Mapping them here shipped both onto the
 * bubble, which right-aligned every line and undid the authored box.
 */
const SPEECH_SOURCE = /\.message-(?:outgoing|incoming)\b/;

/**
 * Published host controls an author's generic button skin should paint.
 *
 * The author wrote `button` once and meant "my chat chrome" — on the source
 * platform that was the whole toolbar. Here the same intent has to name each
 * control, including the ones Dearm adds that the author never knew about
 * (mask, currency switcher, model label), so the whole family stays uniform.
 */
const BUTTON_TARGETS = [
  "nj_chat_input_replay_btn",
  "nj_mask_btn",
  "nj_chat_input_model_btn",
  "nj_currency_switcher",
  "nj_back_button",
  "nj_mobile_drawer_btn",
  "nj_review_btn",
  "nj_header_more_btn",
  "nj_stage_adjust_btn",
] as const;

/**
 * Text fields: the composer shell only.
 *
 * `#nj_chat_input_box` is the wrapper id; the inner textarea is border-0 by
 * contract so the composer reads as one frame. Painting the authored border on
 * both produced a box inside a box — the source page's `textarea` rule only
 * ever addressed its single field, so mapping it to both invents a second
 * frame the author never drew.
 */
const FIELD_TARGETS = ["nj_chat_input_box"] as const;

/**
 * Id repeated this many times.
 *
 * The whitelist ends every scoped stylesheet with a platform reset that repeats
 * each control id 10× so it can never lose to a creator stylesheet. Our
 * recovered skin is the author's own chrome, not a stray creator override, so
 * it has to outrank that reset: 12 ids beat 10 on specificity regardless of
 * source order. Repeating an id is legal CSS and is the same technique the
 * whitelist itself uses.
 */
const ID_BOOST = 12;

function boostId(id: string): string {
  return `#${id}`.repeat(ID_BOOST);
}

/**
 * Text fields take the authored frame only.
 *
 * Border only, never padding. The source page put 8px of padding on its single
 * `<textarea>`; the host puts that on the inner textarea and keeps the wrapper
 * flush. Applying it to the wrapper too inflated the composer from 53px to
 * 72px, which is exactly the "input box is huge" the other cards never showed.
 * Background is skipped for the same reason it was on the source: the platform
 * shell owns the fill, and the author's light colour was already overridden.
 */
const FIELD_PROPERTY = /^(?:border(?:-[\w-]+)?|outline(?:-[\w-]+)?)$/i;

const CONTROL_TAG = /^(?:button|input|textarea|select)$/i;

interface MappedSelector {
  selector: string;
  field: boolean;
}

/** Map one authored selector onto the host controls it actually means. */
function mapControlSelector(selector: string): MappedSelector[] {
  const trimmed = selector.trim();
  if (!trimmed || /\bnj_/.test(trimmed)) return [];

  // Speech bubbles: the source platform's own class names.
  //
  // Dearm renders one AI bubble per segment and has no outgoing/incoming split,
  // so both sides land on the same block — but not equally. On the source the
  // character speaks on the incoming side (left, avatar beside it) and the player
  // on the outgoing side (right). This block only ever holds the character, so
  // an outgoing rule would drag it right and right-align its text, which is the
  // mirror of what the card looks like. Outgoing is therefore dropped; the
  // incoming rules carry the box shape the card is recognised by.
  if (SPEECH_SOURCE.test(trimmed)) {
    if (/\.message-outgoing\b/.test(trimmed)) return [];
    const tail = /\.message-(?:outgoing|incoming|content|container|timestamp)\b([\s\S]*)$/.exec(trimmed)?.[1] ?? "";
    if (tail && !/^[\s,]*$/.test(tail) && !/^[\s,:]+(?:hover|focus)/.test(tail)) return [];
    return [{ selector: SPEECH_TARGET, field: false }];
  }

  const bare = trimmed.replace(/:not\([^()]*\)/g, "").trim();
  const head = /^([a-zA-Z][\w-]*)([\s\S]*)$/.exec(bare);
  if (!head || !CONTROL_TAG.test(head[1])) return [];

  // Button-shaped controls: `<button>`, `input[type=button|submit|reset]`.
  const isButtonShaped =
    /^button$/i.test(head[1]) ||
    /\[type\s*=\s*["']?(?:button|submit|reset)/i.test(trimmed);
  // Keep the authored state/pseudo tail verbatim so :hover, ::before and the
  // rest land on the control they were written for. The input type attribute
  // only selected the source element, so it must not survive the rewrite.
  const tail = head[2].replace(/\[type\s*=\s*["'][^"']*["']\]/gi, "");

  if (isButtonShaped) {
    return BUTTON_TARGETS.map((id) => ({ selector: `${boostId(id)}${tail}`, field: false }));
  }
  return FIELD_TARGETS.map((id) => ({ selector: `${boostId(id)}${tail}`, field: true }));
}

const KEYFRAMES_PARENT = /keyframes$/;

function parentAtRuleName(rule: postcss.Rule): string {
  const parent = rule.parent;
  return parent && parent.type === "atrule" ? parent.name.toLowerCase() : "";
}

function adaptTypography(css: string): string {
  let root: postcss.Root;
  try {
    root = postcss.parse(css);
  } catch {
    return "";
  }
  // Clones are appended after the walk: a clone's selector no longer targets the
  // container, so walking it would delete the rule that was just created.
  const proseRules: postcss.Rule[] = [];
  root.walkRules((rule) => {
    if (KEYFRAMES_PARENT.test(parentAtRuleName(rule))) {
      rule.remove();
      return;
    }
    const rewritten = toRootSelector(rule.selector);
    if (rewritten === null) {
      rule.remove();
      return;
    }
    rule.selector = rewritten;
    // `body` alone is the bubble root: trim it to the type treatment, and give
    // the same treatment to the host blocks that set their own body font.
    if (rule.selectors.every((part) => part === "body")) {
      rule.walkDecls((decl) => {
        if (!ROOT_DECLARATION.test(decl.prop)) decl.remove();
      });
      if (!rule.nodes || rule.nodes.length === 0) {
        rule.remove();
        return;
      }
      const cloned = rule.clone();
      cloned.selector = PROSE_TARGETS.join(", ");
      proseRules.push(cloned);
      return;
    }
    // `body p` / `body li` stay as they are. The whitelist rewrites the `body`
    // head to the scope root, which is exactly what a reply paragraph is: the
    // source put its prose in `p` elements under the text container, and the
    // reply keeps those elements. Dropping the rule here was why the opening
    // above the divider was indented while the reply below it sat flush left.
    //
    // The same paragraph treatment also has to reach the semantic blocks, which
    // are `div`s rather than `p`s. A reply alternates raw `p` prose with
    // `nj_message_narration` and `nj_ai_message_bubble`, so covering only `p`
    // produced exactly the alternating indented/flush-left look.
    if (rule.selectors.every((part) => PARAGRAPH_SELECTOR.test(part))) {
      const treatment = rule.clone();
      treatment.walkDecls((decl) => {
        if (!PARAGRAPH_TREATMENT.test(decl.prop)) decl.remove();
      });
      if (!treatment.nodes || treatment.nodes.length === 0) {
        return;
      }
      treatment.selector = PROSE_TARGETS.join(", ");
      proseRules.push(treatment);
    }
  });
  for (const rule of proseRules) root.append(rule);
  root.walkAtRules((atRule) => {
    if (!/^(?:media|supports)$/i.test(atRule.name)) {
      atRule.remove();
      return;
    }
    if (atRule.nodes && atRule.nodes.length === 0) atRule.remove();
  });
  const value = root.toString().trim();
  return /\{/.test(value) ? value : "";
}

function adaptControls(css: string): string {
  let root: postcss.Root;
  try {
    root = postcss.parse(css);
  } catch {
    return "";
  }
  root.walkRules((rule) => {
    if (KEYFRAMES_PARENT.test(parentAtRuleName(rule))) return;
    const mapped = rule.selectors.flatMap(mapControlSelector);
    if (!mapped.length) {
      rule.remove();
      return;
    }
    rule.selectors = [...new Set(mapped.map((entry) => entry.selector))];
    if (mapped.every((entry) => entry.field)) {
      rule.walkDecls((decl) => {
        if (!FIELD_PROPERTY.test(decl.prop)) decl.remove();
      });
      if (!rule.nodes || rule.nodes.length === 0) rule.remove();
    }
  });
  root.walkAtRules((atRule) => {
    if (!/^(?:media|supports|keyframes)$/i.test(atRule.name)) {
      atRule.remove();
      return;
    }
    if (atRule.nodes && atRule.nodes.length === 0) atRule.remove();
  });
  // A keyframe only earns its place while a surviving rule still names it.
  const retained = root.toString();
  root.walkAtRules((atRule) => {
    if (!/keyframes$/i.test(atRule.name)) return;
    const name = atRule.params.trim();
    if (!name || !new RegExp(`\\b${name}\\b`).test(retained)) atRule.remove();
  });
  const value = root.toString().trim();
  return /\{/.test(value) ? value : "";
}

export interface MufyAuthoredReplySkin {
  /** Reply container typography, already covering the `-no-lines` variant. */
  typography: string;
  /** Authored button and field frame, rewritten onto published host ids. */
  controls: string;
  /** Combined block ready for `sanitizeAndScopeCss`. */
  css: string;
}

/**
 * Whether the card draws its dialogue as speech bubbles at all.
 *
 * Across every migrated card the rule is absolute: a card that defines
 * `.message-incoming` / `.message-outgoing` renders each spoken line in a
 * bordered bubble with the character's avatar beside it, and a card that does
 * not renders plain paragraphs with no avatars. The two never mix, so this one
 * signal decides both — the bubble skin and the avatar.
 */
export function hasMufyAuthoredSpeechSkin(
  components: ReadonlyArray<{ content: string }>,
): boolean {
  for (const { content } of components) {
    if (!content || content.length > 2_097_152) continue;
    for (const match of content.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)) {
      const clean = match[1].replace(/\/\*[\s\S]*?\*\//g, "");
      if (SPEECH_SOURCE.test(clean)) return true;
    }
  }
  return false;
}

/**
 * Extract the author's reply skin. Returns empty strings unless the card
 * actually ships Mufy's `.beautified-text-container` block — that marker is
 * what identifies the card as Mufy-beautified, so ordinary creator CSS never
 * gets rerouted through this path.
 */
export function collectMufyAuthoredReplySkin(
  components: ReadonlyArray<{ content: string }>,
): MufyAuthoredReplySkin {
  const typography: string[] = [];
  const controls: string[] = [];
  let isMufyCard = false;

  for (const { content } of components) {
    if (!content || content.length > 2_097_152) continue;
    for (const match of content.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)) {
      const css = match[1];
      if (css.length > 32_768) continue;
      const clean = css.replace(/\/\*[\s\S]*?\*\//g, "");
      if (/<script/i.test(clean)) continue;
      if (CONTAINER.test(clean)) {
        isMufyCard = true;
        const adapted = adaptTypography(css);
        if (adapted) typography.push(adapted);
        continue;
      }
      if (!/(?:^|[{};,]\s*)(?:button|input|textarea|select)\b/i.test(clean)) continue;
      const adapted = adaptControls(css);
      if (adapted) controls.push(adapted);
    }
  }

  if (!isMufyCard) return { typography: "", controls: "", css: "" };
  return {
    typography: typography.join("\n"),
    controls: controls.join("\n"),
    css: [...typography, ...controls].join("\n").trim(),
  };
}
