import { sanitizeAndScopeCss } from "@/lib/styling/whitelist";
import {
  collectMufyAuthoredReplySkin,
  hasMufyAuthoredSpeechSkin,
  type MufyAuthoredReplySkin,
} from "./mufy-authored-reply-skin";

/**
 * Whether the card draws dialogue as bubbles with the avatar beside each line.
 *
 * Across every migrated card the two travel together, so one signal decides
 * both the bubble skin and the avatar.
 */
export { hasMufyAuthoredSpeechSkin };

/** Public creator component styles only. No prompt, stored-message or host CSS mutation. */
export function collectMufySharedComponentStyle(components: ReadonlyArray<{content:string}>): string {
  const blocks=new Set<string>();
  for(const {content} of components){
    if(content.length>2_097_152)continue;
    for(const match of content.matchAll(/<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi)){
      const css=match[1],clean=css.replace(/\/\*[\s\S]*?\*\//g,'');
      // The known public fire-terminal block is independent from page skin.
      // Do not import a mixed global theme, markup, scripts or unrelated widgets.
      const fire=clean.includes('.mf-fire-widget')&&clean.includes('.mf-fire-panel');
      const state=clean.includes('.m-state-wrapper')&&clean.includes('.m-state-fold');
      const memory=clean.includes('.right-stable-sidebar')&&clean.includes('.right-sidebar-content');
      if(css.length>32768||(!fire&&!state&&!memory))continue;
      if(/<|(?:^|[{}])\s*(?:html|body|:root|\*)\s*[{,]/im.test(clean))continue;
      blocks.add(css);
    }
  }
  return [...blocks].join('\n');
}

export function withMufySharedComponentStyle(srcdoc:string,css:string): string {
  if(!css||!srcdoc.includes('data-mufy-source-skin')||!/class=["'][^"']*\b(?:mf-fire-widget|right-stable-sidebar|m-state-wrapper|m-state-fold)\b/.test(srcdoc))return srcdoc;
  // Source defaults precede explicit reply styles. The live terminal is rendered
  // once in a viewport portal, not once at the bottom of every message canvas.
  return `<style data-mufy-shared-component>${css}</style>`+srcdoc+
    '<style data-mufy-shared-component-layout>.mf-fire-widget{display:none!important}.right-stable-sidebar{display:none!important}</style>';
}

/**
 * The card's own reply skin: authored typography plus the authored chat-control
 * frame, both recovered from the public opening component.
 *
 * Two channels were silently lost at import, and both are visible on one card
 * at once: text above the divider used the author's serif while replies fell
 * back to the host sans, and the chat controls showed the platform default
 * instead of the author's paint. See `mufy-authored-reply-skin.ts` for why each
 * block was dropped.
 */
export function collectMufyReplySkin(
  components: ReadonlyArray<{content:string}>,
): MufyAuthoredReplySkin {
  return collectMufyAuthoredReplySkin(components);
}

/**
 * Reply typography, already scoped to the reply bubble root.
 *
 * A card with an empty stored globalCss still owns its typography. Deriving it
 * from the component keeps the reply on the same typeface as the opening,
 * instead of trusting a channel that can legitimately be blank.
 */
export function collectMufyReplyTypography(
  components: ReadonlyArray<{content:string}>,
): string {
  const {typography}=collectMufyAuthoredReplySkin(components);
  return typography?sanitizeAndScopeCss(typography,'mufy-native-message').css:'';
}

/**
 * Authored control frame for the chat chrome, scoped to the chat page root and
 * emitted after the platform's `globalCss` so it paints the controls the author
 * already skinned on the source platform.
 */
export function collectMufyControlSkin(
  components: ReadonlyArray<{content:string}>,
  scope: string,
): string {
  if(!scope) return '';
  const {controls}=collectMufyAuthoredReplySkin(components);
  return controls?sanitizeAndScopeCss(controls, scope).css:'';
}
