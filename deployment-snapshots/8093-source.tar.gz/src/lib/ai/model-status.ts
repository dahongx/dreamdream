import { and, eq, gt, gte, lt, lte, sql } from "drizzle-orm";
import { NIMIR_VISIBLE_MODELS, type NimirModelId } from "@/lib/ai/models";
import { db } from "@/lib/db/client";
import { modelHealthStatus, modelRequestEvents } from "@/lib/db/schema";
import {
  buildRealModelStatusState,
  classifyModelStability,
  type ModelStabilityStatus,
  mapProbeHealthStatus,
  type RealModelStatusState,
  recoveredChannelSince,
} from "./model-status-state";

export type { ModelStabilityStatus } from "./model-status-state";
export {
  classifyModelStability,
  mapProbeHealthStatus,
} from "./model-status-state";

export const MODEL_STATUS_WINDOW_MINUTES = 30;
const EVENT_RETENTION_HOURS = 24;

export interface ModelStatusSnapshot {
  modelId: NimirModelId;
  /** Average time to first visible character, in seconds (Mufy-compatible). */
  firstCharTimeAvg: number | null;
  recentSuccessRate: number | null;
  stabilityStatus: ModelStabilityStatus;
  sampleCount: number;
  windowMinutes: number;
}

let lastCleanupAt = 0;

/**
 * Record one provider attempt. Callers must omit user aborts, balance errors,
 * content-policy blocks and other failures that do not describe model health.
 * Telemetry failure is intentionally swallowed so it can never break chat.
 */
export async function recordModelAttempt(input: {
  modelId: NimirModelId;
  outcome: "success" | "failure";
  ttftMs: number | null;
  durationMs: number;
  channelFailure?: boolean;
}): Promise<void> {
  const observedAt = new Date();
  try {
    await db.transaction(async (tx) => {
      // Serialize telemetry only, never the provider call. A per-model lock
      // makes read/aggregate/upsert atomic even across application processes.
      await tx.execute(
        sql`select pg_advisory_xact_lock(794023, hashtext(${input.modelId}))`,
      );
      const [saved] = await tx
        .select({ state: modelHealthStatus.realRequestState })
        .from(modelHealthStatus)
        .where(eq(modelHealthStatus.modelId, input.modelId));
      const previous = saved?.state ?? null;
      // PostgreSQL events and JS clocks use millisecond precision here. Keep a
      // later serialized observation distinguishable from a same-ms outage.
      if (previous?.observedAt === observedAt.toISOString()) {
        observedAt.setTime(observedAt.getTime() + 1);
      }
      await tx.insert(modelRequestEvents).values({
        modelId: input.modelId,
        outcome: input.outcome,
        ttftMs: input.ttftMs === null ? null : Math.max(0, input.ttftMs),
        durationMs: Math.max(0, input.durationMs),
        createdAt: observedAt,
      });
      if (previous && previous.observedAt > observedAt.toISOString()) return;
      const attempt = { ...input, observedAt };
      const sinceRecovery = recoveredChannelSince(previous, attempt);
      const [stats] = await tx
        .select({
          sampleCount: sql<number>`count(*)::int`,
          successCount: sql<number>`count(*) filter (where ${modelRequestEvents.outcome} = 'success')::int`,
          averageTtftMs: sql<
            number | null
          >`round(avg(${modelRequestEvents.ttftMs}) filter (where ${modelRequestEvents.outcome} = 'success'))::int`,
        })
        .from(modelRequestEvents)
        .where(
          and(
            eq(modelRequestEvents.modelId, input.modelId),
            gte(
              modelRequestEvents.createdAt,
              new Date(
                observedAt.getTime() - MODEL_STATUS_WINDOW_MINUTES * 60_000,
              ),
            ),
            lte(modelRequestEvents.createdAt, observedAt),
            sinceRecovery
              ? gt(modelRequestEvents.createdAt, sinceRecovery)
              : undefined,
          ),
        );
      const state = buildRealModelStatusState(previous, attempt, stats);
      await tx
        .insert(modelHealthStatus)
        .values({ modelId: input.modelId, realRequestState: state })
        .onConflictDoUpdate({
          target: modelHealthStatus.modelId,
          set: { realRequestState: state, updatedAt: observedAt },
        });
    });

    // Keep this high-volume table bounded without requiring a separate cron.
    // Per-process throttling makes cleanup at most hourly in normal operation.
    const now = Date.now();
    if (now - lastCleanupAt >= 60 * 60 * 1_000) {
      lastCleanupAt = now;
      await db
        .delete(modelRequestEvents)
        .where(
          lt(
            modelRequestEvents.createdAt,
            new Date(now - EVENT_RETENTION_HOURS * 60 * 60 * 1_000),
          ),
        );
    }
  } catch (error) {
    console.error("[model-status] Failed to record model attempt:", error);
  }
}

export async function getRecentModelStatuses(): Promise<ModelStatusSnapshot[]> {
  const windowStart = new Date(
    Date.now() - MODEL_STATUS_WINDOW_MINUTES * 60 * 1_000,
  );
  const [rows, probeRows] = await Promise.all([
    db
      .select({
        modelId: modelRequestEvents.modelId,
        sampleCount: sql<number>`count(*)::int`,
        successCount: sql<number>`count(*) filter (where ${modelRequestEvents.outcome} = 'success')::int`,
        averageTtftMs: sql<
          number | null
        >`round(avg(${modelRequestEvents.ttftMs}) filter (where ${modelRequestEvents.outcome} = 'success'))::int`,
      })
      .from(modelRequestEvents)
      .where(gte(modelRequestEvents.createdAt, windowStart))
      .groupBy(modelRequestEvents.modelId),
    db.select().from(modelHealthStatus),
  ]);

  const byModel = new Map(rows.map((row) => [row.modelId, row]));
  const probeByModel = new Map(probeRows.map((row) => [row.modelId, row]));

  return NIMIR_VISIBLE_MODELS.map((model) => {
    const persisted = probeByModel.get(model.id)?.realRequestState;
    if (persisted) return realRequestSnapshot(model.id, persisted);
    const row = byModel.get(model.id);
    const sampleCount = row?.sampleCount ?? 0;
    const successCount = row?.successCount ?? 0;
    const averageTtftMs = row?.averageTtftMs ?? null;
    const trafficStatus = classifyModelStability({
      sampleCount,
      successCount,
      averageTtftMs,
    });

    if (trafficStatus === "unknown") {
      const probe = probeByModel.get(model.id);
      if (probe?.lastCheckAt) {
        return {
          modelId: model.id,
          firstCharTimeAvg:
            probe.avgLatencyMs === null
              ? null
              : Number((probe.avgLatencyMs / 1_000).toFixed(2)),
          recentSuccessRate:
            probe.checkCount === 0
              ? null
              : Number(
                  ((probe.successCount / probe.checkCount) * 100).toFixed(2),
                ),
          stabilityStatus: mapProbeHealthStatus(probe.status),
          sampleCount: probe.checkCount,
          windowMinutes: MODEL_STATUS_WINDOW_MINUTES,
        };
      }
    }

    return {
      modelId: model.id,
      firstCharTimeAvg:
        averageTtftMs === null
          ? null
          : Number((averageTtftMs / 1_000).toFixed(2)),
      recentSuccessRate:
        sampleCount === 0
          ? null
          : Number(((successCount / sampleCount) * 100).toFixed(2)),
      stabilityStatus: trafficStatus,
      sampleCount,
      windowMinutes: MODEL_STATUS_WINDOW_MINUTES,
    };
  });
}

export function realRequestSnapshot(
  modelId: NimirModelId,
  state: RealModelStatusState,
): ModelStatusSnapshot {
  return {
    modelId,
    firstCharTimeAvg:
      state.averageTtftMs === null
        ? null
        : Number((state.averageTtftMs / 1_000).toFixed(2)),
    recentSuccessRate:
      state.sampleCount === 0
        ? null
        : Number(((state.successCount / state.sampleCount) * 100).toFixed(2)),
    stabilityStatus: state.stabilityStatus,
    sampleCount: state.sampleCount,
    windowMinutes: MODEL_STATUS_WINDOW_MINUTES,
  };
}
