/** Return true only for provider-side rejection of the submitted prompt. */
export function isPromptPolicyRejection(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error ?? "");
  let serialized = "";
  try {
    serialized = JSON.stringify(error);
  } catch {
    // Some SDK errors contain circular request/response objects.
  }
  const detail = `${message}\n${serialized}`.toLowerCase();
  return (
    detail.includes("prompt contains sensitive words") ||
    detail.includes("generative ai prohibited use policy") ||
    detail.includes("prompt was blocked for safety") ||
    detail.includes("prompt_blocked")
  );
}

/** An unavailable channel/account, not a refusal of one submitted prompt. */
export function isModelChannelFailure(error: unknown): boolean {
  if (isPromptPolicyRejection(error)) return false;
  const message = error instanceof Error ? error.message : String(error ?? "");
  let serialized = "";
  try {
    serialized = JSON.stringify(error) ?? "";
  } catch {
    // The Error message remains usable for circular SDK errors.
  }
  const detail = `${message}\n${serialized}`.toLowerCase();
  const status =
    error !== null && typeof error === "object" && "statusCode" in error
      ? error.statusCode
      : null;
  return (
    status === 401 ||
    /no available channel|model_not_found|no (?:available )?channel.*model/.test(
      detail,
    ) ||
    /(?:invalid|incorrect) (?:api[ _-]?key|token)|authentication_error/.test(
      detail,
    ) ||
    /service has been disabled|account.{0,80}(?:disabled|suspended|deactivated)/.test(
      detail,
    ) ||
    /not have a valid license|license.{0,40}(?:invalid|expired)/.test(detail)
  );
}
