"use server";
import { sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { getCurrentUserId } from "@/lib/auth/current-user";
import { getOptionalUserId } from "@/lib/auth/optional-user";
import { db } from "@/lib/db/client";
import { parseRewardAmount } from "./policy";
import { getReferralCode, getReferralSettings } from "./service";

export async function referralLinkAction() {
  const userId = await getOptionalUserId();
  if (!userId) return null;
  const settings = await getReferralSettings();
  return settings.enabled ? await getReferralCode(userId) : null;
}
export async function saveReferralSettings(
  _prev: { ok: boolean } | null,
  form: FormData,
): Promise<{ ok: boolean }> {
  const userId = await getCurrentUserId();
  const [admin] = await db.execute<{ role: string }>(
    sql`SELECT role FROM users WHERE id=${userId}::uuid`,
  );
  if (admin?.role !== "admin") return { ok: false };
  const inviter = parseRewardAmount(form.get("inviter"));
  const invitee = parseRewardAmount(form.get("invitee"));
  if (inviter === null || invitee === null) return { ok: false };
  const enabled = form.get("enabled") === "on";
  try {
    await db.transaction(async (tx) => {
      await tx.execute(
        sql`UPDATE referral_settings SET enabled=${enabled},inviter_amount=${inviter},invitee_amount=${invitee},updated_by=${userId}::uuid,updated_at=now() WHERE id=1`,
      );
      await tx.execute(
        sql`INSERT INTO referral_settings_audit(operator_id,settings) VALUES(${userId}::uuid,${JSON.stringify({ enabled, inviter, invitee })}::jsonb)`,
      );
    });
    revalidatePath("/admin");
    revalidatePath("/me");
    return { ok: true };
  } catch {
    return { ok: false };
  }
}
