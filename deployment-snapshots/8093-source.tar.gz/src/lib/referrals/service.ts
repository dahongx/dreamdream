import { randomBytes, randomUUID } from "node:crypto";
import type { User } from "@supabase/supabase-js";
import { sql } from "drizzle-orm";
import { hashDeactivatedEmailFromEnv } from "@/lib/account/email-hash";
import { db } from "@/lib/db/client";
import {
  isNewReferralIdentity,
  normalizeReferralCode,
  referralSource,
} from "./policy";

export interface ReferralSettings extends Record<string, unknown> {
  enabled: boolean;
  inviter_amount: number;
  invitee_amount: number;
}
export interface ReferralClaim extends Record<string, unknown> {
  id: string;
  inviter_id: string | null;
  invitee_id: string | null;
  email_hash: string;
  code: string;
  source: string;
  inviter_amount: number;
  invitee_amount: number;
  status: "pending" | "paid" | "rejected" | "failed";
  reason: string | null;
  created_at: Date;
  paid_at: Date | null;
  attempts: number;
}
export async function getReferralSettings() {
  const [settings] = await db.execute<ReferralSettings>(
    sql`SELECT enabled,inviter_amount,invitee_amount FROM referral_settings WHERE id=1`,
  );
  if (!settings) throw Error("REFERRAL_SETTINGS_MISSING");
  return settings;
}
export async function getReferralCode(userId: string) {
  const code = randomBytes(8).toString("hex").toUpperCase();
  await db.execute(
    sql`INSERT INTO referral_codes(code,user_id) VALUES(${code},${userId}::uuid) ON CONFLICT(user_id) DO NOTHING`,
  );
  const [row] = await db.execute<{ code: string }>(
    sql`SELECT code FROM referral_codes WHERE user_id=${userId}::uuid`,
  );
  return row.code;
}
export async function validReferralCode(raw: string) {
  const code = normalizeReferralCode(raw);
  if (!code) return false;
  const rows = await db.execute(
    sql`SELECT 1 FROM referral_codes c JOIN referral_settings s ON s.id=1 WHERE c.code=${code} AND s.enabled`,
  );
  return rows.length > 0;
}
/** Server-side intent created BEFORE Auth signUp; later metadata cannot backdate an account. */
export async function createReferralIntent(
  email: string,
  raw: string,
  source: string,
) {
  const code = normalizeReferralCode(raw);
  if (!code) throw Error("REFERRAL_INVALID");
  const emailHash = hashDeactivatedEmailFromEnv(email);
  return db.transaction(async (tx) => {
    await tx.execute(
      sql`SELECT pg_advisory_xact_lock(hashtextextended(${emailHash}, 0))`,
    );
    const [previous] = await tx.execute(
      sql`SELECT 1 FROM referral_claims WHERE email_hash=${emailHash} AND status<>'rejected' AND created_at>now()-interval '1 hour' LIMIT 1`,
    );
    if (previous) throw Error("REFERRAL_RETRY_LATER");
    const id = randomUUID();
    const inserted =
      await tx.execute(sql`INSERT INTO referral_claims(id,inviter_id,email_hash,code,source,inviter_amount,invitee_amount)
      SELECT ${id}::uuid,c.user_id,${emailHash},c.code,${referralSource(source)},s.inviter_amount,s.invitee_amount
      FROM referral_codes c CROSS JOIN referral_settings s WHERE c.code=${code} AND s.id=1 AND s.enabled RETURNING id`);
    if (!inserted.length) throw Error("REFERRAL_INVALID");
    return id;
  });
}
export async function cancelReferralIntent(id: string) {
  await db.execute(
    sql`UPDATE referral_claims SET status='rejected',reason='signup_failed' WHERE id=${id}::uuid AND status='pending' AND invitee_id IS NULL`,
  );
}
/** Called only with a server-verified Auth user, never with client-supplied account fields. */
export async function settleReferral(user: User): Promise<void> {
  const id = user.user_metadata?.referral_intent;
  if (
    typeof id !== "string" ||
    !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i.test(
      id,
    ) ||
    !user.email ||
    !user.email_confirmed_at
  )
    return;
  let emailHash: string;
  try {
    emailHash = hashDeactivatedEmailFromEnv(user.email);
  } catch {
    console.error("[referral] email hash configuration unavailable");
    return;
  }
  try {
    await db.transaction(async (tx) => {
      const [claim] = await tx.execute<ReferralClaim>(
        sql`SELECT * FROM referral_claims WHERE id=${id}::uuid FOR UPDATE`,
      );
      if (!claim || claim.status === "paid" || claim.status === "rejected")
        return;
      if (
        claim.email_hash !== emailHash ||
        !isNewReferralIdentity(user.created_at, new Date(claim.created_at))
      )
        return;
      await tx.execute(
        sql`SELECT pg_advisory_xact_lock(hashtextextended(${emailHash},0))`,
      );
      const [prior] = await tx.execute(
        sql`SELECT 1 FROM referral_claims WHERE (email_hash=${emailHash} AND status='paid') OR (invitee_id=${user.id}::uuid AND id<>${id}::uuid) LIMIT 1`,
      );
      const [deleted] = await tx.execute(
        sql`SELECT 1 FROM deactivated_email_hashes WHERE email_hash=${emailHash} AND deactivated_at < ${user.created_at}::timestamptz`,
      );
      if (
        prior ||
        deleted ||
        !claim.inviter_id ||
        claim.inviter_id === user.id
      ) {
        await tx.execute(
          sql`UPDATE referral_claims SET status='rejected',reason='ineligible_or_already_rewarded' WHERE id=${id}::uuid`,
        );
        return;
      }
      // Deterministic row locking also serializes concurrent wallet spending/rewards.
      const accounts = await tx.execute<{ id: string }>(
        sql`SELECT id FROM users WHERE id IN (${claim.inviter_id}::uuid,${user.id}::uuid) ORDER BY id FOR UPDATE`,
      );
      if (accounts.length !== 2) throw Error("ACCOUNT_NOT_READY");
      const [settings] = await tx.execute<ReferralSettings>(
        sql`SELECT * FROM referral_settings WHERE id=1`,
      );
      if (!settings.enabled) return;
      await tx.execute(
        sql`UPDATE referral_claims SET invitee_id=${user.id}::uuid,attempts=attempts+1 WHERE id=${id}::uuid`,
      );
      for (const [account, amount, note] of [
        [claim.inviter_id, claim.inviter_amount, "referral_inviter"],
        [user.id, claim.invitee_amount, "referral_invitee"],
      ] as const) {
        if (amount === 0) continue;
        const [balance] = await tx.execute<{ silver_balance: number }>(
          sql`UPDATE users SET silver_balance=silver_balance+${amount},updated_at=now() WHERE id=${account}::uuid RETURNING silver_balance`,
        );
        await tx.execute(sql`INSERT INTO currency_transactions(user_id,transaction_type,currency_type,amount,balance_after,note,referral_id)
          VALUES(${account}::uuid,'referral_reward','silver',${amount},${balance.silver_balance},${note},${id}::uuid)`);
      }
      await tx.execute(
        sql`UPDATE referral_claims SET status='paid',reason=NULL,paid_at=now() WHERE id=${id}::uuid`,
      );
    });
  } catch (error) {
    // Persist an operational failure without leaking provider errors or personal data.
    await db
      .execute(
        sql`UPDATE referral_claims SET status='failed',reason='settlement_failed',attempts=attempts+1 WHERE id=${id}::uuid AND email_hash=${emailHash} AND status IN ('pending','failed')`,
      )
      .catch(() => {});
    console.error(
      "[referral] settlement failed",
      id,
      error instanceof Error ? error.name : "Error",
    );
  }
}
