export const REFERRAL_COOKIE = "dearm_referral";
export function parseReferralCookie(raw: string | undefined): {
  code: string;
  source: string;
} {
  try {
    const value: unknown = JSON.parse(raw ?? "null");
    if (value && typeof value === "object" && !Array.isArray(value)) {
      const fields = value as Record<string, unknown>;
      const code = normalizeReferralCode(fields.code);
      if (code) return { code, source: referralSource(fields.source) };
    }
  } catch {
    /* Invalid client cookies must never break registration. */
  }
  return { code: "", source: "/" };
}
export function normalizeReferralCode(value: unknown): string {
  return typeof value === "string" && /^[a-f0-9]{16}$/i.test(value.trim())
    ? value.trim().toUpperCase()
    : "";
}
export function referralSource(value: unknown): string {
  if (typeof value !== "string") return "/";
  // No arbitrary query strings, emails, or external URLs in attribution logs.
  return /^\/share\/[a-f0-9-]{36}$/.test(value) ? value : "/";
}
export function isNewReferralIdentity(
  createdAt: string,
  intentAt: Date,
): boolean {
  const delta = Date.parse(createdAt) - intentAt.getTime();
  return Number.isFinite(delta) && delta >= 0 && delta <= 30 * 60 * 1000;
}
export function parseRewardAmount(value: unknown): number | null {
  if (typeof value !== "string" || !/^\d{1,5}$/.test(value)) return null;
  const amount = Number(value);
  return amount <= 10000 ? amount : null;
}
