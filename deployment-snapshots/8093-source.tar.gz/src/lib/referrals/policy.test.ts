import { describe, expect, test } from "bun:test";
import {
  isNewReferralIdentity,
  normalizeReferralCode,
  parseReferralCookie,
  parseRewardAmount,
  referralSource,
} from "./policy";

describe("referral input boundaries", () => {
  test("normalizes valid codes, rejects other inputs", () => {
    expect(normalizeReferralCode(" abcdef0123456789 ")).toBe(
      "ABCDEF0123456789",
    );
    for (const value of [
      null,
      {},
      123,
      "",
      "abc",
      "abcdefghijklmnop",
      "a".repeat(17),
    ]) {
      expect(normalizeReferralCode(value)).toBe("");
    }
  });
  test("malformed cookies cannot crash signup or supply arbitrary field types", () => {
    for (const raw of [
      undefined,
      "",
      "null",
      "[]",
      "1",
      '"hello"',
      "{",
      '{"code":{}}',
    ]) {
      expect(parseReferralCookie(raw)).toEqual({ code: "", source: "/" });
    }
    expect(
      parseReferralCookie(
        '{"code":"abcdef0123456789","source":"https://evil.invalid"}',
      ),
    ).toEqual({ code: "ABCDEF0123456789", source: "/" });
  });
  test("only internal character share paths are retained", () => {
    const source = "/share/6648459e-137f-4470-bc4f-32ab04aaef5e";
    expect(referralSource(source)).toBe(source);
    for (const value of [
      null,
      "/",
      "//evil.invalid",
      "/admin",
      `${source}?email=private`,
      "https://example.com",
    ]) {
      expect(referralSource(value)).toBe("/");
    }
  });
  test("existing accounts cannot attach a new referral intent", () => {
    const intent = new Date("2026-10-28T00:00:00Z");
    expect(isNewReferralIdentity("2026-10-27T23:59:59Z", intent)).toBe(false);
    expect(isNewReferralIdentity("2026-10-28T00:00:00Z", intent)).toBe(true);
    expect(isNewReferralIdentity("2026-10-28T00:30:00Z", intent)).toBe(true);
    expect(isNewReferralIdentity("2026-10-28T00:30:01Z", intent)).toBe(false);
    expect(isNewReferralIdentity("invalid", intent)).toBe(false);
  });
  test("amounts are bounded whole coins, including zero to disable one side", () => {
    for (const n of ["0", "10", "10000"])
      expect(parseRewardAmount(n)).toBe(Number(n));
    for (const n of [
      "",
      null,
      10,
      "-1",
      "1.5",
      "1e2",
      "10001",
      "Infinity",
      " 10 ",
    ])
      expect(parseRewardAmount(n)).toBeNull();
  });
});
