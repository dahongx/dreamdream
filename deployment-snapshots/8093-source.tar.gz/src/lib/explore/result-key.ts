import type { ExploreSort } from "@/lib/characters/queries";

/** Reset paginated client state when the server returns a new filter result. */
export function exploreResultKey(filters: {
  sort: ExploreSort;
  search: string;
  tag: string;
  excludeTags: string[];
  showNsfw: boolean;
}): string {
  return JSON.stringify([
    filters.sort,
    filters.search,
    filters.tag,
    [...filters.excludeTags].sort(),
    filters.showNsfw,
  ]);
}
