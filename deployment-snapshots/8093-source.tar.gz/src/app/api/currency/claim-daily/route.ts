/**
 * POST /api/currency/claim-daily
 *
 * 每日登录领取银币
 */

import { getCurrentUserId } from "@/lib/auth/current-user";
import { claimDailySilver } from "@/lib/currency/transactions";

export async function POST(request: Request) {
  const userId = await getCurrentUserId();
  const expectedUser = request.headers.get("x-dearm-user-id");
  if (expectedUser && expectedUser !== userId)
    return Response.json({ error: "account_changed" }, { status: 409 });

  const result = await claimDailySilver(userId);

  if (!result.success) {
    return Response.json({ error: result.message }, { status: 400 });
  }

  return Response.json({
    claimed: result.claimed,
    amount: result.amount,
    newBalance: result.newBalance,
    message: result.message,
  });
}
