import { type NextRequest, NextResponse } from "next/server";
import { publicUrl } from "@/lib/auth/urls";
import {
  normalizeReferralCode,
  parseReferralCookie,
  REFERRAL_COOKIE,
  referralSource,
} from "@/lib/referrals/policy";
import { validReferralCode } from "@/lib/referrals/service";

export async function GET(request: NextRequest) {
  const code = normalizeReferralCode(request.nextUrl.searchParams.get("code"));
  const source = referralSource(request.nextUrl.searchParams.get("next"));
  const response = NextResponse.redirect(
    publicUrl(request, source === "/" ? "/signup" : source),
  );
  response.headers.set("Cache-Control", "private, no-store");
  const previous = parseReferralCookie(
    request.cookies.get(REFERRAL_COOKIE)?.value,
  );
  if (
    (await validReferralCode(code)) &&
    (!previous.code || !(await validReferralCode(previous.code)))
  ) {
    response.cookies.set(REFERRAL_COOKIE, JSON.stringify({ code, source }), {
      httpOnly: true,
      sameSite: "lax",
      secure: publicUrl(request, "/").protocol === "https:",
      path: "/",
      maxAge: 30 * 86400,
    });
  }
  return response;
}
